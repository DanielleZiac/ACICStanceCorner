﻿namespace aCICSistanceCorner
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            this.createAcc = new System.Windows.Forms.Button();
            this.backmain = new System.Windows.Forms.Button();
            this.UserName = new System.Windows.Forms.TextBox();
            this.srcode = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // createAcc
            // 
            this.createAcc.BackColor = System.Drawing.Color.Transparent;
            this.createAcc.FlatAppearance.BorderSize = 0;
            this.createAcc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.createAcc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.createAcc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.createAcc.ForeColor = System.Drawing.Color.Transparent;
            this.createAcc.Image = ((System.Drawing.Image)(resources.GetObject("createAcc.Image")));
            this.createAcc.Location = new System.Drawing.Point(42, 601);
            this.createAcc.Name = "createAcc";
            this.createAcc.Size = new System.Drawing.Size(301, 71);
            this.createAcc.TabIndex = 24;
            this.createAcc.UseVisualStyleBackColor = false;
            this.createAcc.Click += new System.EventHandler(this.createAcc_Click);
            // 
            // backmain
            // 
            this.backmain.BackColor = System.Drawing.Color.Transparent;
            this.backmain.FlatAppearance.BorderSize = 0;
            this.backmain.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.backmain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.backmain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backmain.ForeColor = System.Drawing.Color.Transparent;
            this.backmain.Image = ((System.Drawing.Image)(resources.GetObject("backmain.Image")));
            this.backmain.Location = new System.Drawing.Point(42, 678);
            this.backmain.Name = "backmain";
            this.backmain.Size = new System.Drawing.Size(301, 75);
            this.backmain.TabIndex = 25;
            this.backmain.UseVisualStyleBackColor = false;
            this.backmain.Click += new System.EventHandler(this.backmain_Click);
            // 
            // UserName
            // 
            this.UserName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UserName.BackColor = System.Drawing.Color.White;
            this.UserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.UserName.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserName.ForeColor = System.Drawing.Color.Black;
            this.UserName.Location = new System.Drawing.Point(65, 348);
            this.UserName.Name = "UserName";
            this.UserName.PlaceholderText = "Username";
            this.UserName.Size = new System.Drawing.Size(334, 45);
            this.UserName.TabIndex = 26;
            this.UserName.Tag = "";
            // 
            // srcode
            // 
            this.srcode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.srcode.BackColor = System.Drawing.Color.White;
            this.srcode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.srcode.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.srcode.ForeColor = System.Drawing.Color.Black;
            this.srcode.Location = new System.Drawing.Point(65, 432);
            this.srcode.Name = "srcode";
            this.srcode.PlaceholderText = "SR Code";
            this.srcode.Size = new System.Drawing.Size(334, 45);
            this.srcode.TabIndex = 27;
            this.srcode.Tag = "";
            // 
            // password
            // 
            this.password.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.password.BackColor = System.Drawing.Color.White;
            this.password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.password.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.password.ForeColor = System.Drawing.Color.Black;
            this.password.Location = new System.Drawing.Point(65, 514);
            this.password.Name = "password";
            this.password.PlaceholderText = "Password";
            this.password.Size = new System.Drawing.Size(334, 45);
            this.password.TabIndex = 28;
            this.password.Tag = "";
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 844);
            this.Controls.Add(this.password);
            this.Controls.Add(this.srcode);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.backmain);
            this.Controls.Add(this.createAcc);
            this.Name = "Register";
            this.Text = "Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button createAcc;
        private Button backmain;
        private TextBox UserName;
        private TextBox srcode;
        private TextBox password;
    }
}