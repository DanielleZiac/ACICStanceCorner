﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aCICSistanceCorner
{
    public partial class BorrowItems : Form
    {
        public BorrowItems()
        {
            InitializeComponent();
            this.Width = 408;
            this.Height = 891;

            // Set form border style to prevent resizing
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            this.BackgroundImage = aCICSistanceCorner.Properties.Resources.SPORTS_EQUIPMENT_MAIN;

            SSpanel.BackColor = Color.Transparent;

            tabShow.Visible = false;

            // Initialize buttons
            InitializeButtons();
        }
        private void InitializeButtons()
        {
            // Create SignIn button
            CreateImageButton(Properties.Resources.log0, Properties.Resources.log0_, new Point(16, 765), logo_Click);
            CreateImageButton(Properties.Resources.pencil, Properties.Resources.pencil_, new Point(90, 765), pencil_Click);
            CreateImageButton(Properties.Resources.basketball, Properties.Resources.basketball_, new Point(160, 765), basketball_Click);
            CreateImageButton(Properties.Resources.paper, Properties.Resources.paper_, new Point(240, 765), paper_Click);
            CreateImageButton(Properties.Resources.account, Properties.Resources.account_, new Point(315, 765), account_Click);
            CreateImageButton(Properties.Resources.log0, Properties.Resources.log0_, new Point(5, 40), tabLogo_Click);
            CreateImageButton(Properties.Resources.addtocart, Properties.Resources.addtocart_, new Point(320, 130), cart_Click);
        }
        private void CreateImageButton(Image originalImage, Image clickedImage, Point location, MouseEventHandler clickEventHandler)
        {
            PictureBox button = new PictureBox();
            button.Image = originalImage;
            button.Size = originalImage.Size;
            button.Location = location;
            button.SizeMode = PictureBoxSizeMode.AutoSize;
            button.MouseDown += (sender, e) => { button.Image = clickedImage; };
            button.MouseUp += (sender, e) => { button.Image = originalImage; clickEventHandler(sender, e); };
            button.BackColor = Color.Transparent;
            this.Controls.Add(button);
            button.BringToFront();

        }
        private void logo_Click(object sender, EventArgs e)
        {
            this.Close();
            HomePage home = new HomePage();
            home.Show();
        }

        private void pencil_Click(object sender, EventArgs e)
        {
            this.Close();
            marketplace marketPlace = new marketplace();
            marketPlace.Show();
        }

        private void basketball_Click(object sender, EventArgs e)
        {
            this.Close();
            BorrowItems borrow = new BorrowItems();
            borrow.Show();
        }

        private void paper_Click(object sender, EventArgs e)
        {
            this.Close();
            PrintingSerivces print = new PrintingSerivces();
            print.Show();
        }

        private void account_Click(object sender, EventArgs e)
        {
            this.Close(); // Hide the current form

            // Show the homepage form
            Profile profile = new Profile();
            profile.Show();
        }
        private void tabLogo_Click(object sender, EventArgs e)
        {
            this.Close();
            HomePage home = new HomePage();
            home.Show();
        }
        private void cart_Click(object sender, EventArgs e)
        {
           this.Hide(); 
           borrow_tr borrow= new borrow_tr();
           borrow.Show();
        }

        private bool isClicked = false;

        private void quantityCounter_ValueChanged(object sender, EventArgs e)
        {

        }

        private void addcart_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            borrowButton.Image = Properties.Resources.addcart_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                borrowButton.Image = Properties.Resources.addcart;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

        }

        private void BorrowItems_Load(object sender, EventArgs e)
        {

        }

        private void itembasketball_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            itembasketball.Image = Properties.Resources.itembasketball_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                itembasketball.Image = Properties.Resources.itembasketball;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

            tabShow.Visible = true;

            productimage.Image = Properties.Resources.itembasketball;
            productname.Text = "Basketball";
            productname.BackColor = Color.Transparent;
            availablestocks.Text = "Stocks: 2";
            availablestocks.BackColor = Color.Transparent;
            productname.Font = new Font("Arial", 12, FontStyle.Bold);
            availablestocks.Font = new Font("Arial", 10, FontStyle.Regular);
        }

        private void speaker_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            speaker.Image = Properties.Resources.speaker_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                speaker.Image = Properties.Resources.speaker_;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

            tabShow.Visible = true;
            productimage.Image = Properties.Resources.speaker;
            productname.Text = "Speaker";
            productname.BackColor = Color.Transparent;
            availablestocks.Text = "Stocks: 1";
        }

        private void xbutton_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            xbutton.Image = Properties.Resources.x_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                xbutton.Image = Properties.Resources.x;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

            tabShow.Visible = false;
        }

        private void borrowButton_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            borrowButton.Image = Properties.Resources.borrowButton_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                borrowButton.Image = Properties.Resources.borrowButton;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

        }
    }
}
