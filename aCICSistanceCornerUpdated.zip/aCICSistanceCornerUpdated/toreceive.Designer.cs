﻿namespace aCICSistanceCorner
{
    partial class toreceive
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(toreceive));
            this.getnow_tr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // getnow_tr
            // 
            this.getnow_tr.BackColor = System.Drawing.Color.Transparent;
            this.getnow_tr.FlatAppearance.BorderSize = 0;
            this.getnow_tr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.getnow_tr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.getnow_tr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getnow_tr.ForeColor = System.Drawing.Color.Transparent;
            this.getnow_tr.Image = ((System.Drawing.Image)(resources.GetObject("getnow_tr.Image")));
            this.getnow_tr.Location = new System.Drawing.Point(165, 650);
            this.getnow_tr.Name = "getnow_tr";
            this.getnow_tr.Size = new System.Drawing.Size(219, 91);
            this.getnow_tr.TabIndex = 22;
            this.getnow_tr.UseVisualStyleBackColor = false;
            this.getnow_tr.Click += new System.EventHandler(this.getnow_tr_Click);
            // 
            // toreceive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 844);
            this.Controls.Add(this.getnow_tr);
            this.Name = "toreceive";
            this.Text = "toreceive";
            this.ResumeLayout(false);

        }

        #endregion

        private Button getnow_tr;
    }
}