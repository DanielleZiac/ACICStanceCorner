﻿namespace aCICSistanceCorner
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.imagechanger = new System.Windows.Forms.Button();
            this.left = new System.Windows.Forms.Button();
            this.right = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // imagechanger
            // 
            this.imagechanger.BackColor = System.Drawing.Color.Transparent;
            this.imagechanger.FlatAppearance.BorderSize = 0;
            this.imagechanger.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.imagechanger.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.imagechanger.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imagechanger.ForeColor = System.Drawing.Color.Transparent;
            this.imagechanger.Image = ((System.Drawing.Image)(resources.GetObject("imagechanger.Image")));
            this.imagechanger.Location = new System.Drawing.Point(22, 197);
            this.imagechanger.Name = "imagechanger";
            this.imagechanger.Size = new System.Drawing.Size(343, 447);
            this.imagechanger.TabIndex = 27;
            this.imagechanger.UseVisualStyleBackColor = false;
            // 
            // left
            // 
            this.left.BackColor = System.Drawing.Color.Transparent;
            this.left.FlatAppearance.BorderSize = 0;
            this.left.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.left.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.left.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.left.ForeColor = System.Drawing.Color.Transparent;
            this.left.Image = ((System.Drawing.Image)(resources.GetObject("left.Image")));
            this.left.Location = new System.Drawing.Point(64, 381);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(57, 106);
            this.left.TabIndex = 25;
            this.left.UseVisualStyleBackColor = false;
            this.left.Click += new System.EventHandler(this.left_Click);
            // 
            // right
            // 
            this.right.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.right.BackColor = System.Drawing.Color.Transparent;
            this.right.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.right.FlatAppearance.BorderSize = 0;
            this.right.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.right.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.right.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.right.Image = ((System.Drawing.Image)(resources.GetObject("right.Image")));
            this.right.Location = new System.Drawing.Point(271, 381);
            this.right.Margin = new System.Windows.Forms.Padding(0);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(57, 106);
            this.right.TabIndex = 26;
            this.right.UseVisualStyleBackColor = false;
            this.right.Click += new System.EventHandler(this.right_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(390, 844);
            this.Controls.Add(this.right);
            this.Controls.Add(this.left);
            this.Controls.Add(this.imagechanger);
            this.Name = "HomePage";
            this.Text = "Home Page";
            this.TransparencyKey = System.Drawing.SystemColors.ActiveBorder;
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private Button basketball;
        private Button paper;
        private Button account;
        private Button logo;
        private Button button1;
        private Button getStarted;
        private Button left;
        private Button right;
        private Button imagechanger;
        private PictureBox pictureBox1;
    }
}