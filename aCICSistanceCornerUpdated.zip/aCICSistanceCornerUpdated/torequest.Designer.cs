﻿namespace aCICSistanceCorner
{
    partial class borrow_tr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(borrow_tr));
            this.borrownow_tr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // borrownow_tr
            // 
            this.borrownow_tr.BackColor = System.Drawing.Color.Transparent;
            this.borrownow_tr.FlatAppearance.BorderSize = 0;
            this.borrownow_tr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.borrownow_tr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.borrownow_tr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.borrownow_tr.ForeColor = System.Drawing.Color.Transparent;
            this.borrownow_tr.Image = ((System.Drawing.Image)(resources.GetObject("borrownow_tr.Image")));
            this.borrownow_tr.Location = new System.Drawing.Point(165, 650);
            this.borrownow_tr.Name = "borrownow_tr";
            this.borrownow_tr.Size = new System.Drawing.Size(219, 91);
            this.borrownow_tr.TabIndex = 23;
            this.borrownow_tr.UseVisualStyleBackColor = false;
            this.borrownow_tr.Click += new System.EventHandler(this.borrownow_tr_Click);
            // 
            // borrow_tr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 844);
            this.Controls.Add(this.borrownow_tr);
            this.Name = "borrow_tr";
            this.Text = "To Request";
            this.ResumeLayout(false);

        }

        #endregion

        private Button borrownow_tr;
    }
}