﻿namespace aCICSistanceCorner
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.transactions = new System.Windows.Forms.Button();
            this.profilepic = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(34, 394);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(325, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(34, 450);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(325, 50);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(34, 506);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(325, 50);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // transactions
            // 
            this.transactions.BackColor = System.Drawing.Color.Transparent;
            this.transactions.FlatAppearance.BorderSize = 0;
            this.transactions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.transactions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.transactions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.transactions.ForeColor = System.Drawing.Color.Transparent;
            this.transactions.Image = ((System.Drawing.Image)(resources.GetObject("transactions.Image")));
            this.transactions.Location = new System.Drawing.Point(34, 562);
            this.transactions.Name = "transactions";
            this.transactions.Size = new System.Drawing.Size(325, 58);
            this.transactions.TabIndex = 24;
            this.transactions.UseVisualStyleBackColor = false;
            this.transactions.Click += new System.EventHandler(this.transactions_Click);
            // 
            // profilepic
            // 
            this.profilepic.BackColor = System.Drawing.Color.Transparent;
            this.profilepic.FlatAppearance.BorderSize = 0;
            this.profilepic.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.profilepic.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.profilepic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profilepic.ForeColor = System.Drawing.Color.Transparent;
            this.profilepic.Image = global::aCICSistanceCorner.Properties.Resources.profile_icon;
            this.profilepic.Location = new System.Drawing.Point(34, 114);
            this.profilepic.Name = "profilepic";
            this.profilepic.Size = new System.Drawing.Size(325, 274);
            this.profilepic.TabIndex = 25;
            this.profilepic.UseVisualStyleBackColor = false;
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 844);
            this.Controls.Add(this.profilepic);
            this.Controls.Add(this.transactions);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Profile";
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox6;
        private Button transaction;
        private Button transactions;
        private Button profilepic;
    }
}