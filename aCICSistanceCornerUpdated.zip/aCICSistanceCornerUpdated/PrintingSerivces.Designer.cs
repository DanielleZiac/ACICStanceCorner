﻿namespace aCICSistanceCorner
{
    partial class PrintingSerivces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrintingSerivces));
            this.addbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addbutton
            // 
            this.addbutton.BackColor = System.Drawing.Color.Transparent;
            this.addbutton.FlatAppearance.BorderSize = 0;
            this.addbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.addbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.addbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addbutton.ForeColor = System.Drawing.Color.Transparent;
            this.addbutton.Image = ((System.Drawing.Image)(resources.GetObject("addbutton.Image")));
            this.addbutton.Location = new System.Drawing.Point(-3, 600);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(398, 170);
            this.addbutton.TabIndex = 21;
            this.addbutton.UseVisualStyleBackColor = false;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // PrintingSerivces
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 915);
            this.Controls.Add(this.addbutton);
            this.Name = "PrintingSerivces";
            this.Text = "PrintingSerivces";
            this.ResumeLayout(false);

        }

        #endregion

        private Button addbutton;
    }
}