﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace aCICSistanceCorner
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();

            this.Width = 408;
            this.Height = 891;

            // Set form border style to prevent resizing
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            this.BackgroundImage = aCICSistanceCorner.Properties.Resources.MAIN_REGISTER;

            UserName.BorderStyle = BorderStyle.None;
            srcode.BorderStyle = BorderStyle.None;
            password.BorderStyle = BorderStyle.None;

        }

        private void createAcc_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            createAcc.Image = Properties.Resources.CreateAccount_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                createAcc.Image = Properties.Resources.CreateAccount;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();
        }

        private void backmain_Click(object sender, EventArgs e)
        {
            // Change the image to the clicked state
            backmain.Image = Properties.Resources.backmain_;

            // Start a Windows Forms timer to revert back to the original state after a delay
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100; // Adjust the delay time (in milliseconds) as needed
            timer.Tick += (s, args) =>
            {
                // Revert back to the original state
                backmain.Image = Properties.Resources.backmain;

                // Stop and dispose the timer
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();

                this.Close();
                StartingPage main = new StartingPage();
                main.Show();
        }
    }
}
