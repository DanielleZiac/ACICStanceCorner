﻿namespace aCICSistanceCorner
{
    partial class BorrowItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BorrowItems));
            this.itembasketball = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.speaker = new System.Windows.Forms.Button();
            this.SSpanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.quantityCounter = new System.Windows.Forms.NumericUpDown();
            this.borrowButton = new System.Windows.Forms.Button();
            this.productimage = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.stockss = new System.Windows.Forms.Label();
            this.productname = new System.Windows.Forms.Label();
            this.availablestocks = new System.Windows.Forms.Label();
            this.xbutton = new System.Windows.Forms.Button();
            this.tabShow = new System.Windows.Forms.Panel();
            this.SSpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityCounter)).BeginInit();
            this.tabShow.SuspendLayout();
            this.SuspendLayout();
            // 
            // itembasketball
            // 
            this.itembasketball.BackColor = System.Drawing.Color.Transparent;
            this.itembasketball.FlatAppearance.BorderSize = 0;
            this.itembasketball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.itembasketball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.itembasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.itembasketball.ForeColor = System.Drawing.Color.Transparent;
            this.itembasketball.Image = ((System.Drawing.Image)(resources.GetObject("itembasketball.Image")));
            this.itembasketball.Location = new System.Drawing.Point(3, 0);
            this.itembasketball.Name = "itembasketball";
            this.itembasketball.Size = new System.Drawing.Size(114, 121);
            this.itembasketball.TabIndex = 7;
            this.itembasketball.UseVisualStyleBackColor = false;
            this.itembasketball.Click += new System.EventHandler(this.itembasketball_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(232, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(104, 119);
            this.button3.TabIndex = 9;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(3, 127);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 119);
            this.button4.TabIndex = 10;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(114, 127);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 119);
            this.button5.TabIndex = 11;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(225, 127);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(104, 119);
            this.button6.TabIndex = 12;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 251);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(104, 119);
            this.button7.TabIndex = 13;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(114, 251);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(104, 119);
            this.button8.TabIndex = 14;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(225, 251);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(104, 119);
            this.button9.TabIndex = 15;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(114, 375);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(104, 119);
            this.button11.TabIndex = 17;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(3, 375);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(104, 119);
            this.button10.TabIndex = 16;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(225, 375);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(104, 119);
            this.button12.TabIndex = 18;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // speaker
            // 
            this.speaker.BackColor = System.Drawing.Color.Transparent;
            this.speaker.FlatAppearance.BorderSize = 0;
            this.speaker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.speaker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.speaker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.speaker.ForeColor = System.Drawing.Color.Transparent;
            this.speaker.Image = ((System.Drawing.Image)(resources.GetObject("speaker.Image")));
            this.speaker.Location = new System.Drawing.Point(114, 0);
            this.speaker.Name = "speaker";
            this.speaker.Size = new System.Drawing.Size(115, 121);
            this.speaker.TabIndex = 19;
            this.speaker.UseVisualStyleBackColor = false;
            this.speaker.Click += new System.EventHandler(this.speaker_Click);
            // 
            // SSpanel
            // 
            this.SSpanel.AutoScroll = true;
            this.SSpanel.Controls.Add(this.speaker);
            this.SSpanel.Controls.Add(this.button12);
            this.SSpanel.Controls.Add(this.button10);
            this.SSpanel.Controls.Add(this.button11);
            this.SSpanel.Controls.Add(this.button9);
            this.SSpanel.Controls.Add(this.button8);
            this.SSpanel.Controls.Add(this.button7);
            this.SSpanel.Controls.Add(this.button6);
            this.SSpanel.Controls.Add(this.button5);
            this.SSpanel.Controls.Add(this.button4);
            this.SSpanel.Controls.Add(this.button3);
            this.SSpanel.Controls.Add(this.itembasketball);
            this.SSpanel.Location = new System.Drawing.Point(17, 184);
            this.SSpanel.Name = "SSpanel";
            this.SSpanel.Size = new System.Drawing.Size(359, 389);
            this.SSpanel.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::aCICSistanceCorner.Properties.Resources.tab;
            this.pictureBox1.Location = new System.Drawing.Point(5, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(403, 239);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // quantityCounter
            // 
            this.quantityCounter.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.quantityCounter.ForeColor = System.Drawing.SystemColors.WindowText;
            this.quantityCounter.Location = new System.Drawing.Point(254, 76);
            this.quantityCounter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.quantityCounter.Name = "quantityCounter";
            this.quantityCounter.Size = new System.Drawing.Size(94, 23);
            this.quantityCounter.TabIndex = 1;
            // 
            // borrowButton
            // 
            this.borrowButton.BackColor = System.Drawing.Color.Transparent;
            this.borrowButton.FlatAppearance.BorderSize = 0;
            this.borrowButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.borrowButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.borrowButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.borrowButton.ForeColor = System.Drawing.Color.Transparent;
            this.borrowButton.Image = ((System.Drawing.Image)(resources.GetObject("borrowButton.Image")));
            this.borrowButton.Location = new System.Drawing.Point(157, 121);
            this.borrowButton.Name = "borrowButton";
            this.borrowButton.Size = new System.Drawing.Size(191, 62);
            this.borrowButton.TabIndex = 20;
            this.borrowButton.UseVisualStyleBackColor = false;
            this.borrowButton.Click += new System.EventHandler(this.borrowButton_Click);
            // 
            // productimage
            // 
            this.productimage.BackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatAppearance.BorderSize = 0;
            this.productimage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.productimage.ForeColor = System.Drawing.Color.Transparent;
            this.productimage.Location = new System.Drawing.Point(26, 24);
            this.productimage.Name = "productimage";
            this.productimage.Size = new System.Drawing.Size(114, 121);
            this.productimage.TabIndex = 20;
            this.productimage.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 22;
            // 
            // stockss
            // 
            this.stockss.AutoSize = true;
            this.stockss.Location = new System.Drawing.Point(36, 164);
            this.stockss.Name = "stockss";
            this.stockss.Size = new System.Drawing.Size(0, 20);
            this.stockss.TabIndex = 23;
            // 
            // productname
            // 
            this.productname.AutoSize = true;
            this.productname.Location = new System.Drawing.Point(36, 143);
            this.productname.Name = "productname";
            this.productname.Size = new System.Drawing.Size(50, 20);
            this.productname.TabIndex = 24;
            this.productname.Text = "label2";
            // 
            // availablestocks
            // 
            this.availablestocks.AutoSize = true;
            this.availablestocks.Location = new System.Drawing.Point(36, 163);
            this.availablestocks.Name = "availablestocks";
            this.availablestocks.Size = new System.Drawing.Size(50, 20);
            this.availablestocks.TabIndex = 25;
            this.availablestocks.Text = "label3";
            // 
            // xbutton
            // 
            this.xbutton.BackColor = System.Drawing.Color.Transparent;
            this.xbutton.FlatAppearance.BorderSize = 0;
            this.xbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.xbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.xbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xbutton.ForeColor = System.Drawing.Color.Transparent;
            this.xbutton.Image = ((System.Drawing.Image)(resources.GetObject("xbutton.Image")));
            this.xbutton.Location = new System.Drawing.Point(320, 13);
            this.xbutton.Name = "xbutton";
            this.xbutton.Size = new System.Drawing.Size(28, 29);
            this.xbutton.TabIndex = 20;
            this.xbutton.UseVisualStyleBackColor = false;
            this.xbutton.Click += new System.EventHandler(this.xbutton_Click);
            // 
            // tabShow
            // 
            this.tabShow.BackColor = System.Drawing.Color.Transparent;
            this.tabShow.Controls.Add(this.xbutton);
            this.tabShow.Controls.Add(this.availablestocks);
            this.tabShow.Controls.Add(this.productname);
            this.tabShow.Controls.Add(this.stockss);
            this.tabShow.Controls.Add(this.label1);
            this.tabShow.Controls.Add(this.productimage);
            this.tabShow.Controls.Add(this.borrowButton);
            this.tabShow.Controls.Add(this.quantityCounter);
            this.tabShow.Controls.Add(this.pictureBox1);
            this.tabShow.Location = new System.Drawing.Point(12, 531);
            this.tabShow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabShow.Name = "tabShow";
            this.tabShow.Size = new System.Drawing.Size(425, 259);
            this.tabShow.TabIndex = 3;
            // 
            // BorrowItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 915);
            this.Controls.Add(this.tabShow);
            this.Controls.Add(this.SSpanel);
            this.Name = "BorrowItems";
            this.Text = "BorrowItems";
            this.Load += new System.EventHandler(this.BorrowItems_Load);
            this.SSpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityCounter)).EndInit();
            this.tabShow.ResumeLayout(false);
            this.tabShow.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel tabShow;
        private Button xbutton;
        private Label availablestocks;
        private Label productname;
        private Label stockss;
        private Label label1;
        private Button productimage;
        private Button borrowButton;
        private NumericUpDown quantityCounter;
        private PictureBox pictureBox1;
        private Panel SSpanel;
        private Button speaker;
        private Button button12;
        private Button button10;
        private Button button11;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button itembasketball;
        private Button getnow;
        private Button eraser;
        private Button pen;
    }
}