﻿namespace aCICSistanceCorner
{
    partial class marketplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(marketplace));
            this.SSpanel = new System.Windows.Forms.Panel();
            this.eraser = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pen = new System.Windows.Forms.Button();
            this.tabShow = new System.Windows.Forms.Panel();
            this.productimage = new System.Windows.Forms.Button();
            this.getnow = new System.Windows.Forms.Button();
            this.addcart = new System.Windows.Forms.Button();
            this.quantityCounter = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SSpanel.SuspendLayout();
            this.tabShow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.quantityCounter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SSpanel
            // 
            this.SSpanel.AutoScroll = true;
            this.SSpanel.Controls.Add(this.eraser);
            this.SSpanel.Controls.Add(this.button12);
            this.SSpanel.Controls.Add(this.button10);
            this.SSpanel.Controls.Add(this.button11);
            this.SSpanel.Controls.Add(this.button9);
            this.SSpanel.Controls.Add(this.button8);
            this.SSpanel.Controls.Add(this.button7);
            this.SSpanel.Controls.Add(this.button6);
            this.SSpanel.Controls.Add(this.button5);
            this.SSpanel.Controls.Add(this.button4);
            this.SSpanel.Controls.Add(this.button3);
            this.SSpanel.Controls.Add(this.pen);
            this.SSpanel.Location = new System.Drawing.Point(10, 204);
            this.SSpanel.Name = "SSpanel";
            this.SSpanel.Size = new System.Drawing.Size(359, 389);
            this.SSpanel.TabIndex = 0;
            // 
            // eraser
            // 
            this.eraser.BackColor = System.Drawing.Color.Transparent;
            this.eraser.FlatAppearance.BorderSize = 0;
            this.eraser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.eraser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.eraser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eraser.ForeColor = System.Drawing.Color.Transparent;
            this.eraser.Image = ((System.Drawing.Image)(resources.GetObject("eraser.Image")));
            this.eraser.Location = new System.Drawing.Point(114, 0);
            this.eraser.Name = "eraser";
            this.eraser.Size = new System.Drawing.Size(115, 121);
            this.eraser.TabIndex = 19;
            this.eraser.UseVisualStyleBackColor = false;
            this.eraser.Click += new System.EventHandler(this.eraser_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(225, 375);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(104, 119);
            this.button12.TabIndex = 18;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(3, 375);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(104, 119);
            this.button10.TabIndex = 16;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(114, 375);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(104, 119);
            this.button11.TabIndex = 17;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(225, 251);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(104, 119);
            this.button9.TabIndex = 15;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(114, 251);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(104, 119);
            this.button8.TabIndex = 14;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 251);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(104, 119);
            this.button7.TabIndex = 13;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(225, 127);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(104, 119);
            this.button6.TabIndex = 12;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(114, 127);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 119);
            this.button5.TabIndex = 11;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(3, 127);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 119);
            this.button4.TabIndex = 10;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(232, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(104, 119);
            this.button3.TabIndex = 9;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // pen
            // 
            this.pen.BackColor = System.Drawing.Color.Transparent;
            this.pen.FlatAppearance.BorderSize = 0;
            this.pen.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.pen.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.pen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pen.ForeColor = System.Drawing.Color.Transparent;
            this.pen.Image = global::aCICSistanceCorner.Properties.Resources.pen;
            this.pen.Location = new System.Drawing.Point(3, 0);
            this.pen.Name = "pen";
            this.pen.Size = new System.Drawing.Size(114, 121);
            this.pen.TabIndex = 7;
            this.pen.UseVisualStyleBackColor = false;
            this.pen.Click += new System.EventHandler(this.pen_Click);
            // 
            // tabShow
            // 
            this.tabShow.BackColor = System.Drawing.Color.Transparent;
            this.tabShow.Controls.Add(this.productimage);
            this.tabShow.Controls.Add(this.getnow);
            this.tabShow.Controls.Add(this.addcart);
            this.tabShow.Controls.Add(this.quantityCounter);
            this.tabShow.Controls.Add(this.pictureBox1);
            this.tabShow.Location = new System.Drawing.Point(10, 541);
            this.tabShow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabShow.Name = "tabShow";
            this.tabShow.Size = new System.Drawing.Size(425, 259);
            this.tabShow.TabIndex = 1;
            // 
            // productimage
            // 
            this.productimage.BackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatAppearance.BorderSize = 0;
            this.productimage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.productimage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.productimage.ForeColor = System.Drawing.Color.Transparent;
            this.productimage.Image = global::aCICSistanceCorner.Properties.Resources.pen;
            this.productimage.Location = new System.Drawing.Point(26, 24);
            this.productimage.Name = "productimage";
            this.productimage.Size = new System.Drawing.Size(114, 121);
            this.productimage.TabIndex = 20;
            this.productimage.UseVisualStyleBackColor = false;
            // 
            // getnow
            // 
            this.getnow.BackColor = System.Drawing.Color.Transparent;
            this.getnow.FlatAppearance.BorderSize = 0;
            this.getnow.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.getnow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.getnow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getnow.ForeColor = System.Drawing.Color.Transparent;
            this.getnow.Image = ((System.Drawing.Image)(resources.GetObject("getnow.Image")));
            this.getnow.Location = new System.Drawing.Point(241, 122);
            this.getnow.Name = "getnow";
            this.getnow.Size = new System.Drawing.Size(107, 62);
            this.getnow.TabIndex = 21;
            this.getnow.UseVisualStyleBackColor = false;
            this.getnow.Click += new System.EventHandler(this.getnow_Click);
            // 
            // addcart
            // 
            this.addcart.BackColor = System.Drawing.Color.Transparent;
            this.addcart.FlatAppearance.BorderSize = 0;
            this.addcart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.addcart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.addcart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addcart.ForeColor = System.Drawing.Color.Transparent;
            this.addcart.Image = ((System.Drawing.Image)(resources.GetObject("addcart.Image")));
            this.addcart.Location = new System.Drawing.Point(134, 122);
            this.addcart.Name = "addcart";
            this.addcart.Size = new System.Drawing.Size(114, 62);
            this.addcart.TabIndex = 20;
            this.addcart.UseVisualStyleBackColor = false;
            this.addcart.Click += new System.EventHandler(this.addcart_Click);
            // 
            // quantityCounter
            // 
            this.quantityCounter.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.quantityCounter.ForeColor = System.Drawing.SystemColors.WindowText;
            this.quantityCounter.Location = new System.Drawing.Point(254, 76);
            this.quantityCounter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.quantityCounter.Name = "quantityCounter";
            this.quantityCounter.Size = new System.Drawing.Size(94, 23);
            this.quantityCounter.TabIndex = 1;
            this.quantityCounter.ValueChanged += new System.EventHandler(this.quantityCounter_ValueChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::aCICSistanceCorner.Properties.Resources.tab;
            this.pictureBox1.Location = new System.Drawing.Point(5, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(403, 239);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // marketplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 944);
            this.Controls.Add(this.tabShow);
            this.Controls.Add(this.SSpanel);
            this.Name = "marketplace";
            this.Text = "Market Place";
            this.SSpanel.ResumeLayout(false);
            this.tabShow.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.quantityCounter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private VScrollBar vScrollBar1;
        private Button pen;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button12;
        private Button button10;
        private Button button11;
        private Panel SSpanel;
        private Button eraser;
        private Panel tabShow;
        private NumericUpDown numericUpDown1;
        private PictureBox pictureBox1;
        private NumericUpDown quantityCounter;
        private TextBox stocks;
        private TextBox productnamebox;
        private Button productimage;
        private Button button13;
        private Button button2;
        private Button getnow;
        private Button addcart;
    }
}